//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SpyXX.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SpyXX_DIALOG                102
#define IDD_OLE_PROPPAGE_LARGE          105
#define IDD_OLE_PROPPAGE_LARGE1         106
#define IDD_OLE_PROPPAGE_LARGE2         107
#define IDD_OLE_PROPPAGE_LARGE3         108
#define IDD_OLE_PROPPAGE_LARGE4         109
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDI_ICON2                       130
#define IDI_ICON3                       131
#define IDC_CURSOR1                     134
#define IDC_PIC                         1000
#define IDC_TAB1                        1003
#define IDC_ABOUT                       1004
#define IDC_CHKTOP                      1005
#define IDC_CHKBIN                      1006
#define IDC_BUTTON1                     1006
#define IDC_CHKHEX                      1006
#define IDC_EDITHWND                    1007
#define IDC_EDITCLASS                   1008
#define IDC_LIST_STYLE                  1008
#define IDC_EDITTITLE                   1009
#define IDC_LIST_EX_STYLE               1009
#define IDC_EDITRECT                    1010
#define IDC_EDIT_STYLE                  1010
#define IDC_EDITWNDID                   1011
#define IDC_EDIT_EX_STYLE               1011
#define IDC_EDIT1                       1011
#define IDC_MYHWND                      1011
#define IDC_EDITPROCESSID               1012
#define IDC_EDIT2                       1012
#define IDC_MYTITLE                     1012
#define IDC_EDITPATH                    1013
#define IDC_LIST1                       1013
#define IDC_EDIT3                       1013
#define IDC_LISTCLASS                   1013
#define IDC_PREHWND                     1013
#define IDC_EDITVC                      1014
#define IDC_EDIT4                       1014
#define IDC_PRETITLE                    1014
#define IDC_EDITVB                      1015
#define IDC_EDIT5                       1015
#define IDC_LISTSTATUS                  1015
#define IDC_NEXTHWND                    1015
#define IDC_EDIT6                       1016
#define IDC_EDITCLASSNAME               1016
#define IDC_NEXTTITLE                   1016
#define IDC_EDIT7                       1017
#define IDC_EDITCLASSVALUE              1017
#define IDC_PARENTHWND                  1017
#define IDC_EDIT8                       1018
#define IDC_PARENTTITLE                 1018
#define IDC_URL                         1018
#define IDC_EDIT9                       1019
#define IDC_CHILDHWND                   1019
#define IDC_EDIT10                      1020
#define IDC_CHILDTITLE                  1020
#define IDC_EDIT11                      1021
#define IDC_OWNERHWND                   1021
#define IDC_EDIT12                      1022
#define IDC_OWNERTITLE                  1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
